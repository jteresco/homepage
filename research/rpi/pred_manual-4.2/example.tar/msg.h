/**************************************/
/* Taken from Ray Loy's paroct v. 5.2 */
/**************************************/

/* #ifndef SERIAL */
/* #include "pm_util.h" */
/* #else */
extern void mpc_flush(int fd);
/* #endif */


#define MSG_BUFSIZE 1536000

extern int mypid;
extern int nprocs;
extern int msg_temp;

extern void   msg_init(int *argc, char ***argv);
extern void   msg_send_init(void);
extern void   msg_bsend(void *buf, int size, int dest, int type);
extern void   msg_breceive(void *buf, int size, int *from, int type);
extern int    msg_nreceives(void);
extern int    msg_int_sum(int value);
extern double msg_double_sum(double value);
extern int    msg_int_scan(int value);
extern float  msg_float_scan(float value);
extern int    msg_int_bcast(int value, int sender);
extern double msg_double_bcast(double value, int sender);
extern double msg_double_min(double value);
extern double msg_double_max(double value);
extern void   msg_sync(void);
extern void   msg_inorder_begin(void);
extern void   msg_inorder_end(void);
extern void   msg_end(void);
extern void   msg_abort(int errcode);

extern void   msg_block_bcast(void *buf, int size, int sender);

#define printf0   if (mypid==0) printf
#define fprintf0  if (mypid==0) fprintf


#ifndef NOPRINT_IN_ORDER
#define PRINT_IN_ORDER() \
  msg_sync(); \
  if (mypid==0) \
    printf("************************************************************\n"); \
  for (msg_temp=0, mpc_flush(1); msg_temp<nprocs; msg_temp++, mpc_flush(1)) \
    if (mypid==msg_temp)
#else
#define PRINT_IN_ORDER()
#endif


/*
 * Message types
 *
 */


#define MTYPE_INORDER    0

/* migoct.c */
#define MTYPE_OREQ       1
#define MTYPE_OREP       2
#define MTYPE_OUPDATE    3
#define MTYPE_OMIGRATE   4

/* migreg.c */
#define MTYPE_ROOT       5

/* reftest.c */
#define MTYPE_ERRVAL     6

/* octmsg.c */
#define MTYPE_IDREQ      7
#define MTYPE_IDREPLY    8
#define MTYPE_PTRREQ     9
#define MTYPE_PTRREPLY  10

/* facecom.c */
#define MTYPE_FDAT      11
#define MTYPE_UVAL      12

/* node.c */
#define MTYPE_NVAL      13

#define MTYPE_CENTROID  14
