/**************************************/
/* Taken from Ray Loy's paroct v. 5.2 */
/**************************************/

#include <malloc.h>
#include <unistd.h>
#include <fcntl.h>
#include "mdbext.h"
#include "msg.h"
/* commented out LHZ: */
/* #include "pmshext.h" */
/* added LHZ */
#include "pmshops.h"
#include "ref_deref_ops.h"
#include "refine.h"

/*
 * ref_dref_check_files(char *mname)
 *
 * Make sure the refdref.inp and .xmt_txt files exist
 *
 */


void ref_dref_check_files(char *mname)
{
  int fd;
  char pname[128];

  if (mypid>0)
    return;

  fd=open("refdref.inp",O_RDONLY);
  if (fd<0)
    {
      fprintf(stderr,"ref_dref_check_files: fatal: refdref.inp not found\n");
      abort();
    }
  close(fd);
    
  sprintf(pname,"%s.xmt_txt",mname);
  fd=open(pname,O_RDONLY);
    
  if (fd<0)
    {
      fprintf(stderr,"ref_dref_check_files: fatal: %s not found\n",pname);
      abort();
    }
  close(fd);
}




/*
 * ref_errv_max(mesh,pmeshpb,nkeyv,tag)
 * 
 * communicate among processor boundary nodes and set the double value
 * attached to "tag" to be the max among all instances of each node
 *
 * NOTE: should be called by all procs
 *
 */


typedef struct
{
  pVertex vert;
  double errv[1];
} VMSG;


void ref_errv_max(pMesh mesh, pMeshPB pmeshpb, int nkeyv, char *tag)
{
  int i,j;
  void *temp;
  pVertex vert;
  pNode node;
  int nreceives;
  int nlinks;
  double *errv;
  int pid;
  pVertex ptr;
  VMSG *vmsg;
  int vsize;
  int nsends;

  mesh=NULL;  /* Apparently mesh is unused */

  vsize=sizeof(VMSG)+(nkeyv-1)*sizeof(double);
  vmsg=(VMSG *)malloc(vsize);

  nsends=0;
  msg_send_init();
  temp=NULL ;

  while (vert=pmdb_all_next_en(pmeshpb,Tvertex,&temp))
    {
      node = EN_node(vert,0);
      errv= EN_dataP(node,tag);

      nlinks=pmdb_en_num_iplinks((pEntity)vert);
      for (i=0; i<nlinks; i++)
	{
	  pmdb_en_iplink((pEntity)vert,i,&pid,(pEntity)&ptr);
	  vmsg->vert=ptr;
	  for (j=0; j<nkeyv; j++)
	    vmsg->errv[j]=errv[j];
	  msg_bsend(vmsg,vsize,pid,MTYPE_ERRVAL);
	  nsends++;
	}
    }
  
  nreceives=msg_nreceives();
  if (nsends!=nreceives)
    {
      fprintf(stderr,"%d ref_errv_max: nsends=%d nreceives=%d\n",
	      mypid,nsends,nreceives);
      abort();
    }

  for (i=0; i<nreceives; i++)
    {
      msg_breceive(vmsg,vsize,&pid,MTYPE_ERRVAL);
      if (EN_type(vmsg->vert)!=Tvertex)
	{
	  fprintf(stderr,"%d ref_errv_max: received non vertex\n",mypid);
	  abort();
	}
       
      node= EN_node(vmsg->vert,0);
      errv= EN_dataP(node,tag);

      for (j=0; j<nkeyv; j++)
	if (vmsg->errv[j] > errv[j])
	  errv[j]=vmsg->errv[j];
    }
}


/*
 * ref_errv
 *
 * double check that the nodes on interproc boundaries have the
 * same values 
 */


void ref_errv(pMesh mesh, pMeshPB pmeshpb, int nkeyv, char *tag)
{
  int i,j;
  void *temp;
  pVertex vert;
  pNode node;
  int nreceives;
  int nlinks;
  double *errv;
  int pid;
  pVertex ptr;
  VMSG *vmsg;
  int vsize;
  int nsends;

  mesh=NULL;       /* apparently mesh is unused */

  vsize=sizeof(VMSG)+(nkeyv-1)*sizeof(double);
  vmsg=(VMSG *)malloc(vsize);

  nsends=0;
  msg_send_init();
  temp=NULL ;

  while (vert=pmdb_all_next_en(pmeshpb,Tvertex,&temp))
    {
      node = EN_node(vert,0);
      errv= EN_dataP(node,tag);

      nlinks=pmdb_en_num_iplinks((pEntity)vert);
      for (i=0; i<nlinks; i++)
	{
	  pmdb_en_iplink((pEntity)vert,i,&pid,(pEntity)&ptr);
	  vmsg->vert=ptr;
	  for (j=0; j<nkeyv; j++)
	    vmsg->errv[j]=errv[j];
	  msg_bsend(vmsg,vsize,pid,MTYPE_ERRVAL);
	  nsends++;
	}
    }
  
  nreceives=msg_nreceives();
  if (nsends!=nreceives)
    {
      fprintf(stderr,"%d ref_errv: nsends=%d nreceives=%d\n",
	      mypid,nsends,nreceives);
      abort();
    }
	      
  for (i=0; i<nreceives; i++)
    {
      msg_breceive(vmsg,vsize,&pid,MTYPE_ERRVAL);
      if (EN_type(vmsg->vert)!=Tvertex)
	{
	  fprintf(stderr,"%d ref_errv: received non vertex\n",mypid);
	  abort();
	}
       
      node= EN_node(vmsg->vert,0);
      errv= EN_dataP(node,tag);

      for (j=0; j<nkeyv; j++) 
	if (vmsg->errv[j] != errv[j])
	  {
	    fprintf(stderr,"%d ref_errv: not a match\n",mypid);
	    fprintf(stderr,"  i=%d  errv=%f  msg=%f\n",
		    i,errv[j],vmsg->errv[j]);
            abort();
	  }
    }
}


