/**************************************/
/* Taken from Ray Loy's paroct v. 5.2 */
/**************************************/

#include <malloc.h>
#include <stdio.h>
#include <math.h>
#include "mpi.h"
#include "msg.h"

/*
 * interface to message-passing mechanism
 *
 */


int nprocs;                /* GLOBALS !!! */
int mypid;                 /* GLOBALS !!! */
int msg_temp;

static int *receives;
static int bytes_sent;

/*
 * msg_init()
 *
 * call this for initialization before calling any other msg_xxx() routines
 * Among other things, will set globals nprocs and mypid
 *
 */


void msg_init(argc, argv)
int *argc;
char ***argv;
{
  int ret;
  void *bufptr;

  ret=MPI_Init(argc,argv);

  if (ret!=MPI_SUCCESS)
    {
      fprintf(stderr,"msg_inti: MPI_Init() failed\n");
      msg_abort(ret);
    }


  ret=MPI_Comm_rank(MPI_COMM_WORLD,&mypid);

  if (ret!=MPI_SUCCESS)
    {
      fprintf(stderr,"msg_init: MPI_Comm_rank() failed\n");
      msg_abort(ret);
    }


  ret=MPI_Comm_size(MPI_COMM_WORLD,&nprocs);

  if (ret!=MPI_SUCCESS)
    {
      fprintf(stderr,"msg_init: MPI_Comm_size() failed\n");
      msg_abort(ret);
    }


  bufptr=(int *)malloc(MSG_BUFSIZE);

  ret=MPI_Buffer_attach(bufptr,MSG_BUFSIZE);

  if (ret!=MPI_SUCCESS)
    {
      fprintf(stderr,"msg_init: MPI_Buffer_attach() failed\n");
      msg_abort(ret);
    }

  receives=(int *)malloc(sizeof(int) * nprocs);

  if (!receives)
    {
      fprintf(stderr,"msg_init: could not malloc receive array\n");
      abort();
    }
}


void msg_end(void)
{
  MPI_Finalize();
}




/*
 * msg_send_init()
 *
 * call this to initialize the data structure that keeps track
 * of sends.  After calling msg_bsend() as much as desired, this
 * info is used by msg_nreceives() to figure out how many messages
 * each processor will receive.
 *
 */


void msg_send_init()
{
  int i;

  for (i=0; i<nprocs; i++)
    receives[i]=0;

  bytes_sent=0;
}



/*
 * msg_bsend(buf,size,dest,type)
 *
 * Do a send, blocking until buf is free.
 * Checks error codes.
 *
 */

void msg_bsend(buf,size,dest,type)
void *buf;
int size;
int dest;
int type;
{
  int ret;

  if (dest==mypid)
    {
      fprintf(stderr,"%d msg_bsend: attempt to send to self\n",mypid);
      abort();
    }

  if (receives)
    receives[dest]++;
  bytes_sent+=size;

  ret=MPI_Bsend(buf,size,MPI_BYTE,dest,type,MPI_COMM_WORLD);

  if (ret!=MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_bsend: size=%d dest=%d type=%d errno=%d\n",
	      mypid,size,dest,type,ret);
      msg_abort(ret);
    }
}


/*
 * msg_breceive(buf,size,from,type)
 *
 * receive a message of the specified size and type from any other
 * processor.  Size and type must match.
 * Checks for errors.
 *
 */


void msg_breceive(buf,size,from,type)
void *buf;
int size;
int *from;
int type;
{
  int ret;
  int nbytes;
  MPI_Status status;

  ret=MPI_Recv(buf,size,MPI_BYTE,MPI_ANY_SOURCE,type,MPI_COMM_WORLD,&status);

  *from=status.MPI_SOURCE;
  /* MPI_ANY_TAG, status.MPI_TAG */
  
  if (ret!=MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_breceive: receive error ret=%d\n",mypid,ret);
      msg_abort(ret);
    }

  ret=MPI_Get_count(&status,MPI_BYTE,&nbytes);

  if (ret!=MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_breceive: get count failed\n",mypid);
      msg_abort(ret);
    }

  if (nbytes!=size)
    {
      fprintf(stderr,"%d msg_breceive: expected %d bytes but got %d bytes\n",
	      mypid,size,nbytes);
      abort();
    }

}




/*
 * msg_nreceives()
 *
 * all processors should call this to see what they are
 * sending each other.
 *
 * Usage: call msg_send_init(), one or more msg_bsend(),
 * then this to determine how many each processor will receive.
 *
 */


int msg_nreceives()
{
  int rectot,inmsg;
  int i;
  int ret;

  rectot= -1;

  for (i=0; i<nprocs; i++)
    {
      inmsg=0;
      
      ret=MPI_Reduce((void *)&(receives[i]),
		     (void *)&inmsg,
		     1,                     /* one MPI_INT */
		     MPI_INT,
		     MPI_SUM,
		     i,                     /* root */
		     MPI_COMM_WORLD);

      if (ret!= MPI_SUCCESS)
	{
	  fprintf(stderr,"%d msg_nreceives: reduce ret=%d\n",mypid,ret);
	  msg_abort(ret);
	}

      if (mypid==i)
	rectot=inmsg;
    }

  /* printf("msg_nreceives: %7d bytes sent\n",bytes_sent); */
  return(rectot);
}


/*
 * msg_int_sum
 *
 * Sum a value from each processor, and return sum to all
 * processors.
 *
 */

int msg_int_sum(int value)
{
  int recvbuf;
  int ret;

  ret=MPI_Allreduce(&value,&recvbuf,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);

  if (ret!= MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_int_reduce: Allreduce ret=%d\n",mypid,ret);
      msg_abort(ret);
    }

  return(recvbuf);
}




/*
 * msg_double_sum
 *
 * Sum a value from each processor, and return sum to all
 * processors.
 *
 */

double msg_double_sum(double value)
{
  double recvbuf;
  int ret;

  ret=MPI_Allreduce(&value,&recvbuf,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);

  if (ret!= MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_double_reduce: Allreduce ret=%d\n",mypid,ret);
      msg_abort(ret);
    }

  return(recvbuf);
}





/*
 * msg_int_scan
 *
 * perform "exclusive" scan
 *
 * in    v0   v1   v2     v3       ...
 * out    0   v0   v0+v1  v0+v1+v2 ...
 *
 */
 
int msg_int_scan(int value)
{
  int recvbuf;
  int ret;

  ret=MPI_Scan(&value,&recvbuf,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);

  if (ret!= MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_int_scan: Scan ret=%d\n",mypid,ret);
      msg_abort(ret);
    }

  return(recvbuf-value);
}




/*
 * msg_float_scan
 *
 * perform "exclusive" scan
 *
 * in    v0   v1   v2     v3       ...
 * out    0   v0   v0+v1  v0+v1+v2 ...
 *
 */
 
float msg_float_scan(float value)
{
  float recvbuf;
  int ret;

  ret=MPI_Scan(&value,&recvbuf,1,MPI_FLOAT,MPI_SUM,MPI_COMM_WORLD);

  if (ret!= MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_float_scan: Scan ret=%d\n",mypid,ret);
      msg_abort(ret);
    }

  return(recvbuf-value);
}



/*
 * msg_int_bcast
 *
 * broadcast from one proc to all
 *
 */

int msg_int_bcast(int value, int sender)
{
  int ret;

  ret=MPI_Bcast(&value,1,MPI_INT,sender,MPI_COMM_WORLD);

  if (ret!= MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_int_bcast: Bcast ret=%d\n",mypid,ret);
      msg_abort(ret);
    }

  return(value);
}



/*
 * msg_double_bcast
 *
 * broadcast from one proc to all
 *
 */

double msg_double_bcast(double value, int sender)
{
  int ret;

  ret=MPI_Bcast(&value,1,MPI_DOUBLE,sender,MPI_COMM_WORLD);

  if (ret!= MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_double_bcast: Bcast ret=%d\n",mypid,ret);
      msg_abort(ret);
    }

  return(value);
}


/*
 * msg_block_bcast(void *buf, int size, int sender)
 *
 * broadcast a block of data from sender to all other
 * procs.
 *
 */


void msg_block_bcast(void *buf, int size, int sender)
{
  int ret;

  ret=MPI_Bcast(buf,size,MPI_BYTE,sender,MPI_COMM_WORLD);

  if (ret!= MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_block_bcast: Bcast ret=%d\n",mypid,ret);
      msg_abort(ret);
    }
}



/*
 * msg_double_min
 *
 * Find min value across procs
 *
 */

double msg_double_min(double value)
{
  double recvbuf;
  int ret;

  ret=MPI_Allreduce(&value,&recvbuf,1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);

  if (ret!= MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_double_min: Allreduce ret=%d\n",mypid,ret);
      msg_abort(ret);
    }

  return(recvbuf);
}



/*
 * msg_double_max
 *
 * Find max value across procs
 *
 */

double msg_double_max(double value)
{
  double recvbuf;
  int ret;

  ret=MPI_Allreduce(&value,&recvbuf,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);

  if (ret!= MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_double_max: Allreduce ret=%d\n",mypid,ret);
      msg_abort(ret);
    }

  return(recvbuf);
}



/*
 * msg_sync()
 *
 * synchronize all processors
 *
 */

void msg_sync()
{
  int ret;

  ret=MPI_Barrier(MPI_COMM_WORLD);

  if (ret!=MPI_SUCCESS)
    {
      fprintf(stderr,"%d msg_sync: failed, ret=%d\n",mypid,ret);
      msg_abort(ret);
    }
}



/*
 * msg_inorder_begin()
 *
 * start a block of code that the processors should execute
 * one-at-a-time, in order of processor number.
 * End the block of code with msg_inorder_end()
 * 
 */


void msg_inorder_begin()
{
  int from;

  msg_sync();

  if (mypid>0)
    msg_breceive(NULL,0,&from,MTYPE_INORDER);
}


/* 
 * msg_inorder_end()
 *
 * end a block of code that the processors should execute
 * one-at-a-time, in order of processor number.
 * Start the block of code with msg_inorder_begin()
 *
 */

void msg_inorder_end()
{

  if (mypid+1<nprocs)
    msg_bsend(NULL,0,mypid+1,MTYPE_INORDER);

  msg_sync();

}


/*
 * msg_abort(int errcode)
 *
 * Try to abort all tasks
 *
 */


void msg_abort(int errcode)
{
  char errmsg[MPI_MAX_ERROR_STRING];
  int errsize;

  MPI_Error_string(errcode,errmsg,&errsize);
  fprintf(stderr,"%d  error string: %s\n",mypid,errmsg);
  MPI_Abort(MPI_COMM_WORLD,errcode);
  abort();
}




#if MSGMAIN

main(argc,argv)
int argc;
char *argv[];
{
  int i,nr,from,data;

  msg_init(&argc,&argv);
  msg_send_init();

  for (i=0; i<mypid; i++)
    {
      printf("sending to %d\n",i);
      data=100*mypid+i;
      msg_bsend(&data,sizeof(int),i,0);
    }

  /* sleep(1); */
  msg_sync();

  nr=msg_nreceives();
  printf("receives: %d\n",nr);


  sleep(1);
  msg_sync();

  for (i=0; i<nr; i++)
    {
      msg_breceive(&data,sizeof(int),&from,0);
      printf("received from %d : %d\n",from,data);
    }

  msg_sync();

}
#endif

