/**************************************/
/* Taken from Ray Loy's paroct v. 5.2 */
/**************************************/

extern void ref_dref_check_files(char *mname);
extern void ref_errv_max(pMesh mesh, pMeshPB pmeshpb, int nkeyv, char *tag);
extern void ref_errv(pMesh mesh, pMeshPB pmeshpb, int nkeyv, char *tag);
