#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <mpi.h>
#include <pm_util.h>

#include "MSops.h"
#include "pmshops.h"
#include "ref_deref_ops.h" 
#include "partition_ops.h"
#include "util_macros.h"
#include "mdbext.h"

#include "pred.h"

#define ERR_TAG  "errt"
#define SOL_TAG  "solt"


extern void ref_errv(pMesh mesh, pMeshPB pmeshpb, int nkeyv, char *tag);
extern void ref_errv_max(pMesh mesh, pMeshPB pmeshpb, int nkeyv, char *tag);
extern void   msg_init(int *argc, char ***argv);
extern void   msg_end(void);

extern int mpc_flush(int option);

static void gracefully_abort(char *file, char *function, int line, char *msg) ;
static void do_refinement(pMesh,pMeshPB,pGModel,char *,double) ; 
static void print_after_ref_stats(pMesh,pMeshPB);
static void set_predictive(int bal_pred_flag);

#if 1
/* dummy function */
  void GM_entityByID(void);
  void GM_entityByID(void)
  {
    printf("GM_entityByID: stub in main.c should not be called\n");
    abort();
  }
#endif




int main(int argc,
	 char *argv[])
{
    pMesh      mesh ;
    pGModel    model ;
    pMeshPB    pmeshpb ;
    int        num_axis = 3 ;          /* used for ORB partitioning */
    int        axis[] = {0,1,2} ;  /* used for ORB partitioning */
    long       dofs ;
    double     thres ;
    int        num_pieces;
    int        i;
    FILE       *stdfp;
    char       sms_str[256];
    int        bal_pred_flag;


    msg_init(&argc,&argv);
    com_init();
  
    if ( argc != 4 ) {
      if(COM_PID == 0) {
	fprintf(stderr, "Usage : %s <mesh-sms-prefix>  <single-sms-or-multiple-sms> <pred-bal-flag>\n", argv[0]);
	fprintf(stderr, "Reads a mesh and refines it to illustrate the use of predictive balancing.\n");
	fprintf(stderr, "<mesh-sms-prefix> corresponds to the <mesh> in <mesh>.sms or <mesh>.<pid>.sms\n");
	fprintf(stderr, "<single-sms-or-multiple-sms> --  single : read one sms file; multiple : read partitioned-mesh format\n");
#if OCTBAL
	fprintf(stderr, "<pred-bal-flag> --  0 : no predictive; 1 : pred ITB; 2 : pred OCTPART\n");
#else
	fprintf(stderr, "<pred-bal-flag> --  0 : no predictive; 1 : pred ITB\n");
#endif
      }

      gracefully_abort(__FILE__,"main",__LINE__,NULL); 

    }

    strcpy(sms_str, argv[1]);
    strcat(sms_str, ".sms");

    bal_pred_flag = atoi(argv[3]);

    MD_init() ;                 /* initialize the mesh database       */
    model=load_model(argv[1]);
    pmdb_ge_tabl_new(model) ;       /* initialize the (eType,tag) -> pGEntity table */
    mesh = MM_new(1,model) ;    /* make a mesh object                 */

 
    /* determine if reading from one file or from several */
    if (!strcmp(argv[2],"single")) {
      /* load mesh from single file and partition using PSIRB */
      pmdb_init_load_mesh( sms_str, mesh, &pmeshpb, 0 );
      partition( 1, argv[1], mesh, &pmeshpb );
    }
    else
      if (!strcmp(argv[2],"multiple"))
        /* load distributed mesh */
	part_read_sms( argv[1], mesh, &pmeshpb ); 
      else {
	fprintf(stderr, "Incorrect <single-sms-or-multiple-sms> flag on command line -- use 'single' or 'multiple'.\n");
	fprintf(stderr, "Aborting...\n");
	gracefully_abort(__FILE__,"main",__LINE__,NULL);
      }

    /* register error and solution tags so that migration
       is done correctly by PMDB during refinement */
    pmdb_tag_registerP(pmeshpb,Tnode,ERR_TAG,sizeof(double),
			  PMDB_TAG_DEFAULT);

    pmdb_tag_registerP(pmeshpb,Tnode,SOL_TAG,sizeof(double),
			  PMDB_TAG_DEFAULT);

    set_predictive(bal_pred_flag);
 
    do_refinement(mesh,pmeshpb,model,argv[1],0.005) ; 

    print_after_ref_stats(mesh,pmeshpb);

    do_refinement(mesh,pmeshpb,model,argv[1],0.005) ; 

    print_after_ref_stats(mesh,pmeshpb);

    msg_end();

    M_delete(mesh) ;
    MD_exit() ;

    return 0;

}

void do_refinement(pMesh    mesh,
		   pMeshPB  pmeshpb,
		   pGModel  model,
		   char *   model_name,
		   double   allv)
{
    void    *temp ;
    pEntity t ;
    int     nkeyv ;
    double  thres[2] ;
    int     ndof ;
    double  *dum_err ;
    double  *dum_sol ;
    pNode    pnode ;
    double  *d ;

    double startTime,
           refTime;

    temp    = NULL ;
    while ( t = M_nextVertex(mesh,&temp) ) {
      pnode = EN_node(t,0) ;
      if ( (d=EN_dataP(pnode,ERR_TAG)) != NULL) {
	EN_removeData(pnode,ERR_TAG) ;
	free(d) ;
      } 
      if ( (d=EN_dataP(pnode,SOL_TAG)) != NULL) {
	EN_removeData(pnode,SOL_TAG) ;
	free(d) ;
      }
    }

    temp    = NULL ;
    while ( t = M_nextVertex(mesh,&temp) ) {
	pnode = EN_node(t,0) ;
	SAFE_MALLOC(dum_err,double *,sizeof(double)) ;
	SAFE_MALLOC(dum_sol,double *,sizeof(double)) ;

	if (COM_PID == 0)
	  *dum_err = 1.0 ;
	else 
	  *dum_err = 0.0 ;

	*dum_sol = 1.0 ;
	EN_attachDataP(pnode,ERR_TAG,dum_err) ;
	EN_attachDataP(pnode,SOL_TAG,dum_sol) ;
    }


   ndof     = 1 ;
   nkeyv    = 1 ;
   thres[0]     = 0.00  ; thres[1]     = 0.2  ;

   ref_errv_max(mesh, pmeshpb, nkeyv, ERR_TAG); 


   startTime = com_wall_time();

   ref_deref("parasolid",mesh,pmeshpb,model,model_name,nkeyv,thres,
             ERR_TAG,ndof,SOL_TAG) ;

   refTime = com_wall_time() - startTime;

   fprintf(stdout, "[%d] Refinement time = %f\n", COM_PID, refTime);

}


void print_after_ref_stats(pMesh mesh, pMeshPB pmeshpb)
{

  long load,
       num_regions;

  int proc;

  pmdb_metrics(pmeshpb, PMDB_LOCAL_LOAD, &load, NULL);

  num_regions = M_nRegion(mesh);

  for(proc = 0; proc < COM_NUMPROCS; proc++) {
  
    com_all_sync();

    if (proc == COM_PID) 
      printf("[%d] load after ref=%ld (%ld regions)\n", COM_PID, load, num_regions);

  }

}


void set_predictive(int bal_pred_flag)
{ 
    switch(bal_pred_flag) {
      case 0: {
        fprintf(stdout, "No predictive balancing done!!!!\n");
        pred_set_ref_balancing(PRED_NONE);
	break;
      }
      case 1: {
        fprintf(stdout, "Setting pred balancing to itb balance...\n");
        pred_set_ref_balancing(PRED_ITB);
        break;
      }
#if OCTBAL
      case 2: {
	fprintf(stdout, "Setting pred balancing to octree balance...\n");
	pred_set_ref_balancing(PRED_OCT);
	break;
      }
#endif
      default: {
        fprintf(stderr, "Invalid predictive balaning type.\n");
#if OCTBAL 
        fprintf(stderr, "Valid range from %d to %d\n", PRED_NONE, PRED_OCT);
#else
        fprintf(stderr, "Valid range from %d to %d\n", PRED_NONE, PRED_ITB);
#endif
	gracefully_abort(__FILE__,"set_predictive",__LINE__,NULL);
      }  
    }
}



void gracefully_abort(char *file, char *function, int line, char *msg) {

  fflush(stdout);
  fprintf(stderr,"ABORT in %s:%s:%d on processor %d!\n",
          file,function,line,COM_PID);
  if (msg)
    fprintf(stderr,"  ErrMsg: %s\n",msg);

  com_abort(NULL, NULL);
}
